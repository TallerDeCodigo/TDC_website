WordPress Base Theme
=============
![Taller de Código](http://tallerdecodigo.com/wp-content/themes/tallerdecodigo/screenshot.png)

Usar para iniciar un nuevo tema de WordPress

### Credits

Link: http://www.tallerdecodigo.com/<br />
Contributors: Pablo Covarrubias, John Falcon<br />
Tags: wordpress, themes<br />
Tested up to: 3.8<br />
Stable tag: 1.0<br />
License: GPLv2 or later<br />
License URI: http://www.gnu.org/licenses/gpl-2.0.html<br />
